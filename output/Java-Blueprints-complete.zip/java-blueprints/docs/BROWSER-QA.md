# Ручная проверка в браузере

Проверено в in-app browser, Windows, 23 октября 2026. Эти наблюдения не входят в число 166 автоматических тестов.

| Режим | Действие | Наблюдаемый результат |
|---|---|---|
| Local JVM | Открыть Monolith / 1K, countPairs | 51 метод, AST-граф и исходник |
| Local JVM | Просмотреть план | Before/after, причина, ограничения памяти, source hash |
| Local JVM | Применить и проверить | Test Lab, 8/8, baseline/candidate hashes |
| Local JVM | Benchmark 128/512/2048 | Реальные медианы и SAME, 0.65x / 4.16x / 5.15x в этом UI-прогоне |
| Local JVM | Выделить countPairs | BlueprintFunctions.java, delegate, 2 файла |
| Local JVM | Gate после extraction | 8/8, новый candidate hash |
| Local JVM | Evidence ZIP | Экспорт подготовлен, диалог закрыт без ошибки |
| Local JVM | Architecture | Внутренние вызовы, helper dependency, module hints |
| Local JVM | History | Checkpoints применения, gate и extraction |
| Local JVM | Ctrl+K поиск countPairs | Обе сигнатуры с именами файлов и строками |
| Static, без API | Загрузить обзор | PREVIEW, 1052 строки, RECORDED DEMO / NO JVM |
| Static, без API | Сохранённый патч + запись gate | 8/8, явная надпись о записанном прогоне и невыполненных текущих полях |
| Static, без API | Insights и Presentation | Диагностика BP118, метрики и слайды защиты |

Скриншоты: assets/studio-overview.png, quality-gate.png, benchmark.png. Статический режим проверен на локальном HTTP-сервере с теми же web-файлами. Удалённая страница в браузере не проверялась. По выбору владельца Studio 2 оставлена только локальным комплектом: реализация, сборка и архив готовы. Обновление Site не выполнялось; предыдущая опубликованная версия и её аудитория не менялись.

UI-замер отличается от reference capture: это отдельный запуск с другими размерами и состоянием среды. Для чисел в PDF и BENCHMARKS.md используется только studio-reference-results.json.
